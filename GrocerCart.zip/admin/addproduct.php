<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
if($_SERVER["REQUEST_METHOD"]=="POST")			
{
$product_name=$_REQUEST['product_name'];
$fil=$_FILES['fil'];
	$product_pic=$fil['name'];
    $old=$fil['tmp_name'];
	$new="upload/".$product_pic;
	move_uploaded_file($old,$new);
$product_spec=$_REQUEST['product_spec'];
$product_price=$_REQUEST['product_price'];
$scatid=$_REQUEST['scatid'];
$statusid=$_REQUEST['statusid'];
$sql2="insert into product_tbl values(NULL,'".$product_name."','".$product_pic."','".$product_spec."','".$product_price."','".$scatid."','".$statusid."')";
mysqli_query($cn,$sql2);
}
?>

<!=======================================DOCTYPE html=============================================>

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
 function validate()
      {
      
         if( document.f1.product_name.value == "" )
         {
            alert( "Please Provide Product Name!" );
            document.f1.product_name.focus() ;
            return false;
         }  
         var fileInput = document.getElementById("file");
         var filePath  = fileInput.value;
         var allowedExtensions= /(\.jpg|\.jpeg|\.png|\.gif)$/i;
         if(!allowedExtensions.exec(filePath))
         {
          alert( "Please Upload Image File!" );
          fileInput.value='';
          document.f1.fil.focus() ;
          return false;
         }
           
      
     if( document.f1.product_spec.value == "" )
         {
            alert( "Please Provide Product Specification!" );
            document.f1.product_spec.focus() ;
            return false;
         }
      if( document.f1.product_price.value == "" ||
         isNaN( document.f1.product_price.value ) ||
         document.f1.product_price.value.length > 5 )
         {
            alert( "Please Provide a Proper Price!" );
            document.f1.product_price.focus() ;
            return false;
         }       
  
         return true;
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
         <script type="text/javascript">
            
        </script>  
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
<!========================================Form=========================================================>           <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal" method="post" action="" name="f1" onSubmit="return(validate());" enctype="multipart/form-data">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Add Product Details</h3>			
                        	       </div>
 <!========================================Form=========================================================>
 <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Name</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="product_name">
                 </div>
        </div>  
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Pic</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="file" type="file" name="fil">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Specification</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="product_spec">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Product Price</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="product_price">
                 </div>
        </div>
		
        <!--Design for combo box-->			 
			 
			 
			 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Sub-Category</strong></label>
                 <div class="controls">
                    <select id="selectError" name="scatid"> 
                     
                    <?php
                        $sql="select * from subcategory_tbl";
                        $rs=mysqli_query($cn,$sql);
                        while($data=mysqli_fetch_array($rs))
                        {
                          ?>
                        <option value="<?php echo $data['scat_id'];?>">
                            <?php echo $data['scat_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>
        <div class="control-group success">
              <label for="inputError" class="control-label"><strong>Product Status</strong></label>
                 <div class="controls">
                    <select id="selectError" name="statusid"> 
                     
                    <?php
                        $sql1="select * from productstatus_tbl";
                        $rs1=mysqli_query($cn,$sql1);
                        while($data1=mysqli_fetch_array($rs1))
                        {
                          ?>
                        <option value="<?php echo $data1['status_id'];?>">
                            <?php echo $data1['status_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
                
        </div>       
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Save Data</button>                  
        
        
            
            
        </div> 
<!======================================================================================================>
                              
            
            </fieldset>
            </form>
        </div>   
                
   </div>  
                       
<!======================================================================================================>            
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
