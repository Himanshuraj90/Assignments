<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$name=$_REQUEST['name'];
$address=$_REQUEST['address'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$city=$_REQUEST['city'];
$sql1="update contact_tbl set name='".$name."',address='".$address."',email='".$email."',phone_no='".$phone."',city='".$city."' 
where cid=".$did."";
mysqli_query($cn,$sql1);
}
$sql2 = "select * from contact_tbl where cid='".$did."'";
$rs = mysqli_query($cn,$sql2);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
        function goback()
        {
          window.history.back();
        }
  function validate()
      {
      
         if( document.f1.name.value == "" )
         {
            alert( "Please Provide Name!" );
            document.f1.name.focus() ;
            return false;
         }
         if( document.f1.address.value == "" )
         {
            alert( "Please Provide Address!" );
            document.f1.address.focus() ;
            return false;
         }
     var email = document.f1.email.value;
         atpos = email.indexOf("@");
         dotpos = email.lastIndexOf(".");
      if (atpos < 1 || ( dotpos - atpos < 2 )) 
         {
            alert("Please Enter Correct Email ID")
            document.f1.email.focus() ;
            return false;
         }
      if( document.f1.phone.value == "" ||
         isNaN( document.f1.phone.value ) ||
         document.f1.phone.value.length != 10 )
         {
            alert( "Please Provide a Valid Mobile Number in the format ##########." );
            document.f1.phone.focus() ;
            return false;
         }
  
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update Contact Details</h3>
                        	       </div>
  
          <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Name</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="name" value="<?php echo $d['name'];?>">
                 </div>
        </div>

        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Address</strong></label>
                 <div class="controls">
                    <textarea name="address" id="inputError"><?php echo $d['address'];?></textarea>
                 </div>
        </div>
		
		<div class="control-group success">
              <label class="control-label" for="inputError"><strong>Email</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="email" value="<?php echo $d['email'];?>">
                 </div>
        </div>
		<div class="control-group success">
              <label class="control-label" for="inputError"><strong>Phone</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="phone" value="<?php echo $d['phone_no'];?>">
                 </div>
                 </div>
                 <div class="control-group success">
              <label for="inputError" class="control-label"><strong>City</strong></label>
                 <div class="controls">
                    <select id="selectError" name="city"> 
                     
                    <?php
                        $sql="select * from city_tbl";
                        $rs=mysqli_query($cn,$sql);
                        while($data=mysqli_fetch_array($rs))
                        {
                          ?>
                        <option value="<?php echo $data['city_id'];?>" <?php if($data['city_id']==$d['city']){?> 
                        selected="selected"<?php }?>>
                            <?php echo $data['city_name'];?>
                        </option>
                        <?php
                        }
                        ?>
                        
                    </select>
                     
                        </div>
        </div>

      
        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Update Data</button>                  
        
        
            
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
           <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button>     
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
