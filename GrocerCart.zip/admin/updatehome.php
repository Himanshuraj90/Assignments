<?php
include("config.php");

if($_SESSION["is_login"]=="" or !isset($_SESSION['is_login']))
{
    header("location:index.php");
}
$did=$_REQUEST['did'];
if($_SERVER["REQUEST_METHOD"]=="POST")
{
$title=$_REQUEST['title'];
$fil=$_FILES['fil'];
	$product_pic=$fil['name'];
    $old=$fil['tmp_name'];
	$new="upload/".$product_pic;
	move_uploaded_file($old,$new);
$subtitle=$_REQUEST['subtitle'];
$spec=$_REQUEST['spec'];
if($product_pic=="")
{
$sql="update home_tbl set title='".$title."',subtitle='".$subtitle."',spec='".$spec."' where home_id=".$did."";
mysqli_query($cn,$sql);
}
else
{
$sql2="update home_tbl set title='".$title."',pic='".$product_pic."',subtitle='".$subtitle."',spec='".$spec."' where home_id=".$did."";
mysqli_query($cn,$sql2);	
}
}
$sql1 = "select * from home_tbl where home_id='".$did."'";
$rs = mysqli_query($cn,$sql1);
$d = mysqli_fetch_array($rs);
?>

<!--=======================================DOCTYPE html=============================================-->

<html lang="en">
    <head><title>Grocercart.com/Admin</title>
      <script>
        function goback()
        {
          window.history.back();
        }
 function validate()
      {
      
         if( document.f1.title.value == "" )
         {
            alert( "Please Provide Title!" );
            document.f1.title.focus() ;
            return false;
         }  
         if( document.f1.fil.value != "" )
         {
         var fileInput = document.getElementById("file");
         var filePath  = fileInput.value;
         var allowedExtensions= /(\.jpg|\.jpeg|\.png|\.gif)$/i;
         if(!allowedExtensions.exec(filePath))
         {
          alert( "Please Upload Image File!" );
          fileInput.value='';
          document.f1.fil.focus() ;
          return false;
         }
         }

         if( document.f1.subtitle.value == "" )
         {
            alert( "Please Provide Sub-Title!" );
            document.f1.subtitle.focus() ;
            return false;
         }
      
     if( document.f1.spec.value == "" )
         {
            alert( "Please Provide Specification!" );
            document.f1.spec.focus() ;
            return false;
         }  
  
         return( true );
      }
   
</script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content=""> 

        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- MetisMenu CSS -->
        <link href="css/metisMenu.min.css" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="css/startmin.css" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">

        
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        
        
        
        
          
    </head>
    
    <body>

        <div id="wrapper">

                <?php include("header.php");?>      
         
                <?php include("sidebar.php");?> 
                
                
  <br/>     
            
       <div id="page-wrapper">
    
           <div class="span10">
            
                        <form class="form-horizontal"  method="post" action="" name="f1" onSubmit="return(validate());" enctype="multipart/form-data">
                                     
                          <fieldset>
                                   <div class="alert alert-success">
                                      <h3>Update Home</h3>
                        	       </div>
  
          <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Title</strong></label>
                 <div class="controls">
                    <input type="text" id="inputError" name="title" value="<?php echo $d['title'];?>">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Item Pic</strong></label>
                 <div class="controls" align="left">
                        
              <label class="control-label" for="inputError"><strong>Old Pic &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp <img src="upload\<?php echo $d['pic'];?>" height="200" width="200" /></strong></label>             
                     <br/>
                     <br/>
                     <br/>
                  &nbsp &nbsp &nbsp  <input class="input-xlarge focused" id="file" type="file" name="fil">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Subtitle</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="subtitle" value="<?php echo $d['subtitle'];?>">
                 </div>
        </div>
        <div class="control-group success">
              <label class="control-label" for="inputError"><strong>Specification</strong></label>
                 <div class="controls">
                    <input class="input-xlarge focused" id="focusedInput" type="text" name="spec" value="<?php echo $d['spec'];?>">
                 </div>
        </div>
         

        <div class="form-actions">                    
        <button type="submit" class="btn btn-success">Update Data</button>                  
        
        
            
        </div>                               
            
            </fieldset>
            </form>
        </div>   
        <button type="submit" class="btn btn-danger"  onClick="return(goback())">Go Back</button>        
   </div>  
                                   
            </div>
            
            
        <!-- /#wrapper -->

        <!-- jQuery -->
        <script src="js/jquery.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="js/metisMenu.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="js/startmin.js"></script>

    </body>
</html>
