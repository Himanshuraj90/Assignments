package com.deloitte.grocery.main;

import java.util.*;

import com.deloitte.grocery.model.*;
import com.deloitte.grocery.services.*;

public class DemoGrocery {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int y = 0;
		ArrayList<UserDetails> u1 = new ArrayList<UserDetails>();
		Service i2 = new Service();
		while (true) {
			System.out.println("----------Enter your choice------");
			System.out.println("1 for Add user ");
			System.out.println("2 for login ");
			System.out.println("3 to display all users");
			System.out.println("4 to exit the application");
			System.out.println("---------------------------------");
			y = sc.nextInt();

			switch (y) {

			case 1: {

				System.out.println("Enter userId");
				int userId = Integer.parseInt(sc.next());
				System.out.println("Enter name ");
				String name = sc.next();
				System.out.println("Enter Email Id");
				String email = sc.next();
				System.out.println("Enter userName");
				String userName = sc.next();
				System.out.println("Enter Contact number");
				String phNo = sc.next();
				System.out.println("Enter Pasword");
				String pass = sc.next();
				i2.addUser(userId, name, email, userName, phNo, pass);
				break;

			}

			case 2: {
				System.out.println("Enter UserName");
				String userName = sc.next();
				System.out.println("Enter Pasword");
				String pass = sc.next();
				boolean b=i2.loginUser(userName,pass);
				if(b==true)
					System.out.println("Login Successful");
				else
					System.out.println("Login Failed");
				break;
			}
		
			case 3: {
				u1 = i2.displayUser();
				if(u1==null)
					System.out.println("NO DATA");
				else
				{
				for(UserDetails p:u1 )
				System.out.println(p);}
				break;
			}

			case 4: {
				System.exit(0);
				break;
			}

			}
		}

	}
}
