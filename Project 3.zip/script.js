

function validate()
{var array1=document.getElementById("abc").value;
 if(array1==0)
 {  document.getElementById("1").innerHTML="Please select a City";
	return false;
}

 
}