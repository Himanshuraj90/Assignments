function validatename()
{	var a=document.getElementById("name").value;
    var p="[A-Z][a-z]+"
	if(!a.match(p))
     document.getElementById("nameerror").innerHTML="Please enter name in specified Format : 1st letter capital and only alphabets";
	else
	 document.getElementById("nameerror").innerHTML="";
	
}
function validateFname()
{	var a=document.getElementById("Fname").value;
    var p="[A-Z][a-z]+"
	if(!a.match(p))
     document.getElementById("Fnameerror").innerHTML="Please enter name in specified Format : 1st letter capital and only alphabets";
	else
	 document.getElementById("Fnameerror").innerHTML="";
	
}
function validatephno()
{	var a=document.getElementById("phno").value;
    var p="[0-9]{10}"
	if(!a.match(p))
     document.getElementById("phnoerror").innerHTML="Please enter contact number : 10 digits only ";
	else
	 document.getElementById("phnoerror").innerHTML="";
	
}

function validatecity()
{	var a=document.getElementById("city").value;
    if(a==0)
     document.getElementById("cityerror").innerHTML="Please Select one";
	else
	 document.getElementById("cityerror").innerHTML="";
	
}


